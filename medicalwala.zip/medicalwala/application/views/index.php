
<div id="container">
	

	<div id="body" style="width:80%;margin:30px auto;">
	<h3>Add New Artical Details.</h3>

	<div class="col-md-6">
	<?php echo form_open_multipart('home/addartical');?>	
	<div class="form-group">
			<label for="exampleInputEmail1">Title</label>
			
			<input type="text" class="form-control" name="title" id="exampleInputEmail1" value="<?= set_value('title'); ?>"  aria-describedby="emailHelp">
			<small id="error" class="form-text text-danger"><?php echo form_error('title'); ?></small>
		</div>
		<div class="form-group">
			<label for="exampleFormControlTextarea1">Description</label>
			<textarea class="form-control" name="description" id="exampleFormControlTextarea1" rows="3"><?= set_value('description'); ?></textarea>
			<small id="error" class="form-text text-danger"><?php echo form_error('description'); ?></small>
		</div>
		<div class="form-group">
			<label for="exampleInputPassword1">Author</label>
			<input type="text" class="form-control" name="author" id="exampleInputPassword1" value="<?= set_value('author'); ?>" >
			<small id="error" class="form-text text-danger"><?php echo form_error('author'); ?></small>
		</div>
		<!-- <div class="input-group mb-3">
			<div class="input-group-prepend">
				<span class="input-group-text">Upload Image</span>
			</div>
			
			<div class="custom-file">
				<input type="file" class="custom-file-input" name="file" id="inputGroupFile01">
				<label class="custom-file-label" for="inputGroupFile01">Choose file</label>
			</div>
		
			</div>	 -->
			<input type="file" name="file" size="20" />
			<small id="error" class="form-text text-danger"><?php echo form_error('file'); ?></small>
			<br/>
			<input type="submit" class="btn btn-primary" value="Submit">
			</form>
			</div>
		</div>

	
</div>


</body>
