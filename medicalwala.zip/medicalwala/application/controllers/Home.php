<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	function  __construct() {
		parent::__construct();
		 /* Load form helper */ 
		 $this->load->helper(array('form', 'url'));
		 $this->load->library('upload');
        $this->load->model('Data');
    }
    
	public function index()
	{	
		$this->load->helper('url');
		$this->load->view('header');
		$this->load->view('Menu');
		$this->load->view('index');
		$this->load->view('footer');
	}
	public function addartical(){
		 
			
		  /* Load form validation library */ 
		  $this->load->library('form_validation');
			 
		  /* Set validation rule for name field in the form */ 
		  $this->form_validation->set_rules('title', 'Title', 'required'); 
		  $this->form_validation->set_rules('description', 'Description', 'required'); 
		  $this->form_validation->set_rules('author', 'Author', 'required'); 
		  //$this->form_validation->set_rules('file', 'File', 'required'); 
			 
		  if ($this->form_validation->run() == FALSE) { 

			$this->load->view('header');
			$this->load->view('Menu');
			$this->load->view('index');
			$this->load->view('footer');
		  }else{
			
			$title=$this->input->post('title');
			$description=$this->input->post('description');
			$author=$this->input->post('author');
		
		if(!is_dir('upload/'.$title)){
			mkdir('upload/'.$title,0777,TRUE);
		}	

		$config['upload_path']          = 'upload/'.$title;
		$config['allowed_types']        = 'gif|jpg|png|pdf|doc';
		$config['max_size']             = 10000;
		// $config['max_width']            = 1024;
		// $config['max_height']           = 768;
		//$config['file_name']             = $title;

		$this->load->library('upload', $config);
		$this->upload->initialize($config);
		
		
		if ( ! $this->upload->do_upload('file'))
		{
				
			$this->form_validation->set_error_delimiters('<p class="error">', '</p>');
			$error = array('error' => $this->upload->display_errors());
			//print_r($error);
			$this->load->view('header');
			$this->load->view('Menu');
			$this->load->view('index',$error);
			$this->load->view('footer');
		}
		else
		{
			$data = array($this->upload->data());
			$fileLocation = 'upload/'.$title.'/'.$data[0]['file_name'];


			$data = array(
				'title' => $title,
				'description' => $description,
				'author' => $author,
				'image' => $fileLocation
			);	
			
			$insertUserData = $this->Data->insertData($data);
			$data['Viewartical'] = $this->Data->view();

			$this->load->view('header');
			$this->load->view('Menu');
			$this->load->view('viewartical',$data);
			$this->load->view('footer');
		}
		} 
	}

	public function viewartical(){
		$data['Viewartical'] = $this->Data->view();
		$this->load->helper('url');
		$this->load->view('header');
		$this->load->view('Menu');
		$this->load->view('viewArtical',$data);
		$this->load->view('footer');
	}
	public function deletedata(){
		$id = $this->input->get('id');
		$this->Data->deleteData($id);
		redirect("Home/viewartical");
	}

}
