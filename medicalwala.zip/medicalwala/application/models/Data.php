<?php
class Data extends CI_Model{
    function __construct() {
       parent::__construct();
    }
    
    public function insertData($data){
       $this->db->insert("post",$data);  
    }
    public function view(){
        $query = $this->db->get('post');
        return $query->result();
    }
    public function deleteData($id){
        $this->db->query("delete from post where postId='".$id."'");
    }
}